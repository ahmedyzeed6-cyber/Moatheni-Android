# مؤذني — Android starter
This is a starter Android WebView app, not a finished prayer-time/adhan app.
GitHub Actions installs Gradle 8.9 and builds a debug APK. Run **Build Moatheni APK** from Actions and download the `Moatheni-debug-APK` artifact after success.

Limitations: prayer times are placeholders; scheduled adhan/background alarms, DND automation and restoration, and a complete Quran/audio library are not implemented yet.
